package U4.PRACTICA;

public enum Tipo {cajero, reponedor, gerente, seguridad
}
