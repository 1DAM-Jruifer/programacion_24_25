package U4.PRACTICA;

import java.time.LocalDate;
import java.time.Month;

public class Ejercico4 {
    public static void main(String[] args) {
        Empleado a = new Empleado("Pablo Motos", 13, 605823802, LocalDate.of(2024, Month.JANUARY,3), Tipo.reponedor);
    }
}
